<template>
    <div id="app">
        <router-view></router-view>
    </div>
</template>
<style>
body,
#app {
    overflow-y: visible;
    background-color: #f6f6f6;
}

html {

    overflow-y: scroll;
    background-color: #f6f6f6;
}
</style>