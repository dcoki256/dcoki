<template>
    <div class="foot-container">
        <div class="author">二手交易平台</div>
    </div>
</template>

<script>
    export default {
        name: "Foot"
    }
</script>

<style scoped>
    .foot-container {
        width: 100%;
        display: flex;
        justify-content: center;
        height: 40px;
        padding-top: 10px;
        padding-bottom: 20px;
        background-color: #FFF0F5;
    }

    .author {
        color: #999999;
        font-size: 14px;
    }
</style>